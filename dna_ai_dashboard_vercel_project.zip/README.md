# DNA AI Dashboard

## วิธีรันบนเครื่อง
```bash
npm install
npm run dev
```

## วิธีอัปขึ้น Vercel
1. แตก ZIP
2. อัปโหลดโฟลเดอร์นี้เข้า GitHub
3. เข้า vercel.com > Add New Project
4. เลือก repo นี้
5. กด Deploy

เว็บจะใช้งานบน Safari ได้ทันที
